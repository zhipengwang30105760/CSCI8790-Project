package insertmethodbody;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Loader;
import javassist.NotFoundException;
import util.UtilFile;
import util.UtilMenu;

public class InsertMethodBody {
	static String WORK_DIR = System.getProperty("user.dir");
	static String INPUT_DIR = WORK_DIR + File.separator + "classfiles";
	static String OUTPUT_DIR = WORK_DIR + File.separator + "output";
	static String className = "";
	static String methodName = "";
	static int parameterIndex = 0;

	static String _L_ = System.lineSeparator();

	public static void main(String[] args) throws InstantiationException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println(
						"[DBG] Please input an application class name and a field name (e.g. ComponentApp,foo,1 or ServiceApp,bar,2).");
				String[] arguments = UtilMenu.getArguments();
				if (arguments.length == 3) {
					className = "target." + arguments[0];
					methodName = arguments[1];
					parameterIndex = Integer.parseInt(arguments[2]);
					// System.out.println("Class name is: " + className);
					process(className, methodName, parameterIndex);
				} else {
					System.out.println("[DNG]Invalid input");
				}

			}
		}
	}

	public static void process(String className, String methodName, int parameterIndex) throws InstantiationException,
			IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		try {
			ClassPool pool = ClassPool.getDefault();
			pool.insertClassPath(INPUT_DIR);
			CtClass cc = pool.get(className);
			CtMethod m = cc.getDeclaredMethod(methodName);
			if (parameterIndex == 1) {
				String block1 = "{ " + _L_ //
						+ "System.out.println(\"[DBG] param1: \" + $1); " + _L_ //
						+ "}";
				//System.out.println(block1);
				m.insertBefore(block1);
				cc.writeFile(OUTPUT_DIR);
				// System.out.println("[DBG] write output to: " + OUTPUT_DIR);
				// System.out.println("[DBG] \t" + UtilFile.getShortFileName(OUTPUT_DIR));

				ClassPool cp = ClassPool.getDefault();
				Loader cl = new Loader(cp);
				Class<?> c = cl.loadClass(cc.getName());
				String[] var = null;
				// System.out.println("Class name is: " + cc.getName());
				c.getDeclaredMethod("main", new Class[] { String[].class }). //
						invoke(null, new Object[] { var });
			} else if (parameterIndex == 2) {
				String block2 = "{ " + _L_ //
						+ "System.out.println(\"[DBG] param2: \" + $2); " + _L_ + //
						"}";
				//System.out.println(block2);
				m.insertBefore(block2);
				cc.writeFile(OUTPUT_DIR);
				// System.out.println("[DBG] write output to: " + OUTPUT_DIR);
				// System.out.println("[DBG] \t" + UtilFile.getShortFileName(OUTPUT_DIR));

				ClassPool cp = ClassPool.getDefault();
				Loader cl = new Loader(cp);
				Class<?> c = cl.loadClass(cc.getName());
				String[] var = null;
				// System.out.println("Class name is: " + cc.getName());
				c.getDeclaredMethod("main", new Class[] { String[].class }). //
						invoke(null, new Object[] { var });
			}
			/*
			 * String block1 = "{ " + _L_ // +
			 * "System.out.println(\"[DBG] param1: \" + $1); " + _L_ // +
			 * "System.out.println(\"[DBG] param2: \" + $2); " + _L_ + // "}";
			 * System.out.println(block1); m.insertBefore(block1); cc.writeFile(OUTPUT_DIR);
			 * System.out.println("[DBG] write output to: " + OUTPUT_DIR);
			 * System.out.println("[DBG] \t" + UtilFile.getShortFileName(OUTPUT_DIR));
			 */
		} catch (NotFoundException | CannotCompileException | IOException | IllegalAccessException
				| ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
