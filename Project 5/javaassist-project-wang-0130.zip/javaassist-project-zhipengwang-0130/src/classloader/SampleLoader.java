package classloader;

import java.io.File;
import java.io.IOException;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.Modifier;
import javassist.NotFoundException;
import util.UtilMenu;

public class SampleLoader extends ClassLoader {
	static String WORK_DIR = System.getProperty("user.dir");
	static String INPUT_DIR = WORK_DIR + File.separator + "classfiles";
	static String TARGET_APP = "";
	static String TARGET_FIELD = "";
	private ClassPool pool;

	public static void main(String[] args) throws Throwable {
		
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println("[DBG] Please input an application class name and a field name (e.g. ComponentApp,f1 or ServiceApp,f2).");
				String[] arguments = UtilMenu.getArguments();
				TARGET_APP = arguments[0];
				TARGET_FIELD = arguments[1];
				/*
				 * System.out.println("class name is: " + TARGET_APP);
				 * System.out.println("field name is: " + TARGET_FIELD);
				 */
				SampleLoader loader = new SampleLoader();
				Class<?> c = loader.loadClass(TARGET_APP);
				c.getDeclaredMethod("main", new Class[] { String[].class }). //
						invoke(null, new Object[] { arguments });
			}
		}

	}

	public SampleLoader() throws NotFoundException {
		pool = new ClassPool();
		pool.insertClassPath(INPUT_DIR); // Search MyApp.class in this path.
	}

	/*
	 * Find a specified class, and modify the bytecode.
	 */
	@Override
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		try {
			CtClass cc = pool.get(name);
			if (name.equals(TARGET_APP)) {
				
				CtField f = new CtField(CtClass.doubleType, TARGET_FIELD, cc);
				f.setModifiers(Modifier.PUBLIC);
				
				//the place that have mistakes
				cc.addField(f);
				//System.out.println("check place");
			}
			byte[] b = cc.toBytecode();
			return defineClass(name, b, 0, b.length);
		} catch (NotFoundException e) {
			throw new ClassNotFoundException();
		} catch (IOException e) {
			throw new ClassNotFoundException();
		} catch (CannotCompileException e) {
			e.printStackTrace();
			throw new ClassNotFoundException();
			
		}
	}
}
