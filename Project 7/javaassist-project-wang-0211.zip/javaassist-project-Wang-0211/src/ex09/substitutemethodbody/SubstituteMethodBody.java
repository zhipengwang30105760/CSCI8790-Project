package ex09.substitutemethodbody;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;
import util.UtilMenu;

public class SubstituteMethodBody extends ClassLoader {
	static final String WORK_DIR = System.getProperty("user.dir");
	static final String INPUT_PATH = WORK_DIR + File.separator + "classfiles";


	static String className = "";
	static String methodName = "";
	static String parameterIndex = "";
	static String assignedValue = "";
	static ArrayList<String> checkList = new ArrayList<String>();

	static String _L_ = System.lineSeparator();

	public static void main(String[] args) throws Throwable {
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println(
						"[DBG] Please input an application class name and a field name (e.g. ComponentApp,move,1,0 or ServiceApp,fill,2,10).");
				String[] arguments = UtilMenu.getArguments();
				if (arguments.length == 4) {
					className = "target." + arguments[0];
					methodName = arguments[1];
					parameterIndex = arguments[2];
					assignedValue = arguments[3];
					// System.out.println("Class name is: " + className);
					// process(className, methodName, parameterIndex, assignedValue);
					if (checkList.contains(methodName)) {
						System.out.println("[WRN] This method name" + methodName + " has been modified!!");
					} else {
						
						SubstituteMethodBody s = new SubstituteMethodBody();
							System.out.println(className);
							Class<?> c = s.loadClass(className);
							
							Method mainMethod = c.getDeclaredMethod("main", new Class[] { String[].class });
							mainMethod.invoke(null, new Object[] { args });
							checkList.add(methodName);
					}
				} else {
					System.out.println("[DNG]Invalid input");
				}

			}
		}
	}

	private ClassPool pool;


	public SubstituteMethodBody() throws NotFoundException {
		pool = new ClassPool();
		pool.insertClassPath(new ClassClassPath(new java.lang.Object().getClass()));
		pool.insertClassPath(INPUT_PATH); // "target" must be there.
		System.out.println("[DBG] Class Pathes: " + pool.toString());
	}

	/*
	 * Finds a specified class. The bytecode for that class can be modified.
	 */
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		CtClass cc = null;
		try {
			cc = pool.get(name);
			if (!cc.getName().equals(className)) {
				return defineClass(name, cc.toBytecode(), 0, cc.toBytecode().length);
			}

			cc.instrument(new ExprEditor() {
				public void edit(MethodCall call) throws CannotCompileException {
					
						/*
						String className = call.getClassName();
						String methodName = call.getMethodName();
	
						System.out.println("[Edited by ClassLoader] method name: " + methodName + ", line: " + call.getLineNumber());
						String block2 = "{" + _L_ //
								+ "System.out.println(\"\tReset param to zero.\"); " + _L_//
								+ "$1 = 0; " + _L_ //
								+ "$proceed($$); " + _L_ //
								+ "}";
						System.out.println("[DBG] BLOCK2: " + block2);
						System.out.println("------------------------");
						call.replace(block2);
						*/
					String className = call.getClassName();
		               String methodName = call.getMethodName();
		             if (className.equals(className) && (methodName.equals("move") || methodName.equals("fill"))) {
		                  System.out.println("[Edited by ClassLoader] method name: " + methodName + ", line: " + call.getLineNumber());
		                  String block2 = "{" + _L_ //
		                        + "System.out.println(\"\tReset param " + parameterIndex + " to " + assignedValue + ".\"); " + _L_ //
		                        + "$" + parameterIndex + "=" + assignedValue + "; " + _L_ //
		                        + "$proceed($$); " + _L_ //
		                        + "}";
		                  System.out.println("[DBG] BLOCK2: " + block2);
		                  System.out.println("------------------------");
		                  call.replace(block2);
		               }
					
				}
			});
			byte[] b = cc.toBytecode();
			return defineClass(name, b, 0, b.length);
		} catch (NotFoundException e) {
			throw new ClassNotFoundException();
		} catch (IOException e) {
			throw new ClassNotFoundException();
		} catch (CannotCompileException e) {
			e.printStackTrace();
			throw new ClassNotFoundException();
		}
	}
}
