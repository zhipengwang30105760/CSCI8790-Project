package ex05.javassistloader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;

public class SetSuper {

	static String workDir = System.getProperty("user.dir");
	static String outputDir = workDir + File.separator + "classfiles";
	private String Father;
	private String Child1;
	private String Child2;
	private static Scanner scanner = new Scanner(System.in);

	public SetSuper(String Father, String Child1, String Child2) {
		this.Father = Father;
		this.Child1 = Child1;
		this.Child2 = Child2;
		setSuper(Father, Child1, Child2);
		/*
		 * System.out.println("Father is: " + this.Father);
		 * System.out.println("Child1 is: " + this.Child1);
		 * System.out.println("Child2 is: " + this.Child2);
		 */
	}

	public void setSuper(String Father, String Child1, String Child2) {

		String[] inputs = { Father, Child1, Child2 };
		String father = inputs[0];
		// print out the input name
		for (int i = 0; i < inputs.length; i++) {
			if ((inputs[i].startsWith("Common") && !father.startsWith("Common")) || (inputs[i].startsWith("Common")
					&& father.startsWith("Common") && inputs[i].length() > father.length())) {
				father = inputs[i];
			}
		}
		String[] child = { "", "" };
		int i = 0;
		for (String name : inputs) {
			if (!name.equals(father)) {
				child[i] = name;
				i++;
			}
		}

		this.Father = father;
		this.Child1 = child[0];
		this.Child2 = child[1];

		System.out.println(Father);
		System.out.println(Child1);
		System.out.println(Child2);

		try {
			ClassPool pool = ClassPool.getDefault();
			insertClassPath(pool);
			CtClass ccFather = pool.get("target." + this.Father);
			ccFather.writeFile(outputDir); // debugWriteFile
			System.out.println("[DBG] write output to: " + outputDir);

			CtClass ccChild1 = pool.get("target." + this.Child1);
			ccChild1.writeFile(outputDir);
			System.out.println("[DBG] write output to: " + outputDir);

			CtClass ccChild2 = pool.get("target." + this.Child2);
			ccChild2.writeFile(outputDir);

			ccChild1.defrost(); // modifications of the class definition will be permitted.
			ccChild1.setSuperclass(ccFather);

			ccChild1.writeFile(outputDir);
			System.out.println("[DBG] write output to: " + outputDir);

			ccChild2.defrost(); // modifications of the class definition will be permitted.
			ccChild2.setSuperclass(ccFather);

			ccChild2.writeFile(outputDir);
			System.out.println("[DBG] write output to: " + outputDir);

		} catch (NotFoundException | CannotCompileException | IOException e) {
			e.printStackTrace();
		}

	}

	/*
	 * static void insertClassPath(ClassPool pool) throws NotFoundException { String
	 * strClassPath = outputDir; pool.insertClassPath(strClassPath);
	 * System.out.println("[DBG] insert classpath: " + strClassPath); }
	 */
	static void insertClassPath(ClassPool pool) throws NotFoundException {
		String strClassPath = System.getProperty("user.dir") + File.separator + "classfiles";
		pool.insertClassPath(strClassPath);
		System.out.println("[DBG] insert classpath: " + strClassPath);
	}

	public static String[] getInputs() {
		String input = scanner.nextLine();
		if (input.trim().equalsIgnoreCase("q")) {
			System.err.println("Terminated.");
			System.exit(0);
		}
		List<String> list = new ArrayList<String>();
		String[] inputArr = input.split(",");
		for (String iElem : inputArr) {
			list.add(iElem.trim());
		}
		return list.toArray(new String[0]);
	}

	public String getFather() {
		return this.Father;
	}

	public String getChild1() {
		return this.Child1;
	}

	public String getChild2() {
		return this.Child2;
	}
}
