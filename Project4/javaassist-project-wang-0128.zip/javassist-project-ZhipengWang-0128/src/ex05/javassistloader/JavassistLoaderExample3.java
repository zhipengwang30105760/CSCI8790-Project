package ex05.javassistloader;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.Loader;
import javassist.NotFoundException;
import util.UtilMenu;

public class JavassistLoaderExample3 {
	private static final String WORK_DIR = System.getProperty("user.dir");
	private static String TARGET_POINT = "";
	private static String TARGET_RECTANGLE = "";
	private static String TARGET_CIRCLE = "";
	private static ArrayList<String> methodList = new ArrayList<String>();

	public static void main(String[] args) {

		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println("[DBG] Please input three classes first (e.g. Point,Circle,Rectangle).");
				String[] arguments1 = UtilMenu.getArguments();
				if (arguments1.length == 3) {
					SetSuper s = new SetSuper(arguments1[0], arguments1[1], arguments1[2]);
					TARGET_POINT = "target." + s.getFather();
					TARGET_RECTANGLE = "target." + s.getChild1();
					TARGET_CIRCLE = "target." + s.getChild2();
					/*
					 * System.out.println(TARGET_POINT); System.out.println(TARGET_RECTANGLE);
					 * System.out.println(TARGET_CIRCLE);
					 */
				} else {
					System.out.println("[WAR] Invalid Input");
				}
				break;
			case 2:
				System.out.println("[DBG] Please input three methods first (e.g. add,incX();,getX() or remove,incY();,getY()).");
				String[] arguments2 = UtilMenu.getArguments();
				if (TARGET_POINT.equals("")) {
					System.out.println("[DBG] Please input three classes first (e.g. Point,Circle,Rectangle).");
					break;
				} else if (arguments2.length == 3) {
					
					if(!methodList.contains(arguments2[0])) {
						methodList.add(arguments2[0]);
						analysisProcess(arguments2[0], arguments2[1], arguments2[2]);
					}
					else {
						System.out.println("[WRN] This method \"method name\" have been modified");
					}
					
				} else {
					System.out.println("[WAR] Invalid Input");
				}
			default:
				break;
			}
		}
	}

	static void analysisProcess(String methodDecl, String methodCall, String methodGetter) {
		try {
			ClassPool cp = ClassPool.getDefault();
			insertClassPath(cp);

			CtClass cc1 = cp.get(TARGET_RECTANGLE);
			CtClass cc2 = cp.get(TARGET_CIRCLE);
			// cc.setSuperclass(cp.get(TARGET_POINT));

			CtMethod m1 = cc1.getDeclaredMethod(methodDecl);
			String BLK1 = "\n{\n" //
					+ "\t" + methodCall + "" + "\n" //
					+ "\t" + "System.out.println(\"[TR] " + methodGetter + " result : \"" + "+" + methodGetter + "); " + "\n" + "}";
			System.out.println("[DBG] Block: " + BLK1);
			cc1.defrost();
			m1.insertBefore(BLK1);

			Loader cl1 = new Loader(cp);
			Class<?> c1 = cl1.loadClass(TARGET_RECTANGLE);
			Object rect1 = c1.newInstance();
			System.out.println("[DBG] Created a " + TARGET_RECTANGLE + " object.");

			Class<?> rectClass1 = rect1.getClass();
			Method m11 = rectClass1.getDeclaredMethod(methodDecl, new Class[] {});
			System.out.println("[DBG] Called " + methodCall + ".");
			Object invoker1 = m11.invoke(rect1, new Object[] {});
			System.out.println("[DBG] " + methodDecl + " result: " + invoker1);

			CtMethod m2 = cc2.getDeclaredMethod(methodDecl);
			String BLK2 = "\n{\n" //
					+ "\t" + methodCall + "" + "\n" //
					+ "\t" + "System.out.println(\"[TR] " + methodGetter + " result : \"" + "+" + methodGetter + "); " + "\n" + "}";
			System.out.println("[DBG] Block: " + BLK2);
			cc2.defrost();
			m2.insertBefore(BLK2);

			Loader cl2 = new Loader(cp);
			Class<?> c2 = cl2.loadClass(TARGET_CIRCLE);
			Object rect2 = c2.newInstance();
			System.out.println("[DBG] Created a " + TARGET_CIRCLE + " object.");

			Class<?> rectClass2 = rect2.getClass();
			Method m12 = rectClass2.getDeclaredMethod(methodDecl, new Class[] {});

			System.out.println("[DBG] Called " + methodCall + ".");
			Object invoker2 = m12.invoke(rect2, new Object[] {});
			System.out.println("[DBG] " + methodDecl + " result: " + invoker2);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static void insertClassPath(ClassPool pool) throws NotFoundException {
		String strClassPath = WORK_DIR + File.separator + "classfiles";
		pool.insertClassPath(strClassPath);
		System.out.println("[DBG] insert classpath: " + strClassPath);
	}
}
