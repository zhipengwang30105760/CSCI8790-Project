package newexpr;

public class example {

	public static void main(String[] args) {
		//String cName = $_.getClass().getName();
		//String fName = $_.getClass().getDeclaredFields()[0].getName();
		//String fieldFullName = cName + "." + fName;
		/*
		 * int fieldValue = $_.comX; System.out.println("  [Instrument] " +
		 * fieldFullName + ": " + fieldValue);
		 */
		String fieldType = "int";
		String fieldName = "comX";
		int i = 0;
		String block1 = "String cName = $_.getClass().getName();" + "\n" + "String fName = $_.getClass().getDeclaredFields()[" + i + "].getName();" + "\n"
		+ "String fieldFullName = cName + \".\" + fName;" + "\n" + fieldType + " fieldValue = $_." + fieldName + ";"
				+ "\n" + "System.out.println(\"  [Instrument] \" + fieldFullName + \": \" + fieldValue);";
		System.out.println(block1);
	}
}
