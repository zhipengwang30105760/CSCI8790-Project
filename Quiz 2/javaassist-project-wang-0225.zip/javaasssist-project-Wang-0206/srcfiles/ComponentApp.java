package target;

public class ComponentApp {
   public void foo(int x, int y, int z) {
	   //System.out.println("[DBG] foo called");
   }
   private void hello(int x) {
	   //System.out.println("[DBG] hello called");
   }
   
   public static void main(String[] args) {
	   ComponentApp f = new ComponentApp();
	   f.foo(1, 2, 3);
	   f.hello(4);
   }
}
