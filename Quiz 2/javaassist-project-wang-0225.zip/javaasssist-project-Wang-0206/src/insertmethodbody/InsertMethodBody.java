package insertmethodbody;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.Loader;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.NewExpr;
import util.UtilFile;
import util.UtilMenu;

public class InsertMethodBody {
	static String WORK_DIR = System.getProperty("user.dir");
	static String INPUT_DIR = WORK_DIR + File.separator + "classfiles";
	static String OUTPUT_DIR = WORK_DIR + File.separator + "output";
	static String className = "";
	static String methodName = "";
	static String numberofParameter = "";
	static ArrayList<String> checkList = new ArrayList<String>();
	static int realLength = 0;
	static String _L_ = System.lineSeparator();

	public static void main(String[] args) throws InstantiationException, IllegalArgumentException,
			InvocationTargetException, NoSuchMethodException, SecurityException, NotFoundException {
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println(
						"[DBG] Please input an application class name and a method name and number of methods (e.g. ComponentApp,foo,1 or ServiceApp,bar,2).");
				String[] arguments = UtilMenu.getArguments();
				if (arguments.length == 3) {
					className = "target." + arguments[0];
					methodName = arguments[1];
					numberofParameter = arguments[2];
					System.out.println(
							"A user enters 3 inputs: " + className + ", " + methodName + ", " + numberofParameter);
					ClassPool pool = ClassPool.getDefault();
					pool.insertClassPath(INPUT_DIR);
					CtClass cc = pool.get(className);
					cc.defrost();
					CtMethod m = null;
					try {
						m = cc.getDeclaredMethod(methodName);
					}
					catch(Exception e){
						System.out.println("[WRN]Invalid input method!!");
						continue;
					}
					if (m.toString().contains("public")) {
					if (checkList.contains(methodName)) {
						System.out.println("[WRN]Invalid input method!!");
					} else {
						process(className, methodName, numberofParameter);
					}}
					else {
						System.out.println("[WRN]Cannot modify private method!!");
					}
				} else {
					System.out.println("[WRN]Invalid input size!!");
				}

			}
		}
	}

	public static void process(String className, String methodName, String numberofParameter)
			throws InstantiationException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException,
			SecurityException {
		try {
			ClassPool pool = ClassPool.getDefault();
			pool.insertClassPath(INPUT_DIR);
			CtClass cc = pool.get(className);
			cc.defrost();
			CtMethod m = cc.getDeclaredMethod(methodName);
			//System.out.println("Method found" + m.toString());
			CtClass[] length1 =  m.getParameterTypes();
			realLength = length1.length;
			//System.out.println("Length1 is:" + length1.length);
			
			
			int length = Integer.parseInt(numberofParameter);
			String block2 = "";
			if(length <= realLength) {
			for(int i = 1; i <= length; i++) {
				block2 += "{ " + _L_ //
		                 + "System.out.println(\"[Inserted] " + className+"."+ methodName+"'s param " + i +": \" + $" + i +"); " + _L_+ //
		                 "}\n";
			}
			}
			else {
				block2 = "{ " + _L_ //
		                 + "System.out.println(\"[Inserted] " + className+"."+ methodName+"'s param " + realLength +": \" + $" + realLength +"); " + _L_+ //
		                 "}\n";
			}
			// System.out.println(block2);
			m.insertBefore(block2);
			cc.writeFile(OUTPUT_DIR);
			// System.out.println("[DBG] write output to: " + OUTPUT_DIR);
			// System.out.println("[DBG] \t" + UtilFile.getShortFileName(OUTPUT_DIR));

			ClassPool cp = ClassPool.getDefault();
			Loader cl = new Loader(cp);
			Class<?> c = cl.loadClass(cc.getName());
			String[] var = null;
			// System.out.println("Class name is: " + cc.getName());
			c.getDeclaredMethod("main", new Class[] { String[].class }). //
					invoke(null, new Object[] { var });

			/*
			 * String block1 = "{ " + _L_ // +
			 * "System.out.println(\"[DBG] param1: \" + $1); " + _L_ // +
			 * "System.out.println(\"[DBG] param2: \" + $2); " + _L_ + // "}";
			 * System.out.println(block1); m.insertBefore(block1); cc.writeFile(OUTPUT_DIR);
			 * System.out.println("[DBG] write output to: " + OUTPUT_DIR);
			 * System.out.println("[DBG] \t" + UtilFile.getShortFileName(OUTPUT_DIR));
			 */
		} catch (NotFoundException | CannotCompileException | IOException | IllegalAccessException
				| ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
