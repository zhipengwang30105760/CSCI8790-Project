package newfield;

import java.io.File;
import target.Author;
import target.Column;
import target.Table;

import java.lang.reflect.Proxy;
import java.util.Iterator;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationImpl;
import javassist.bytecode.annotation.MemberValue;
import util.UtilMenu;

public class mainProgram {
	static String workDir = System.getProperty("user.dir");
	static String inputDir = workDir + File.separator + "classfiles";
	static String outputDir = workDir + File.separator + "output";
	static String class_name, first_annotation, second_annotation;

	public static void main(String[] args) {
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println("Enter the four inputs: (e.g, ComponentApp,Column,Author, or ServiceApp,Row,Author)");
				String[] arguments = UtilMenu.getArguments();
				try {
					if (arguments.length == 3) {
						class_name = "target." + arguments[0];
						first_annotation = "target." + arguments[1];
						second_annotation = "target." + arguments[2];

						ClassPool pool = ClassPool.getDefault();
						pool.insertClassPath(inputDir);

						CtClass ct = pool.get(class_name);
						CtField[] all_fields = ct.getFields();
						for (CtField cf : all_fields) {
							process(cf.getAnnotations());

						}
					} else {
						System.out.println("[WRN] Invalid input size");
					}
				} catch (NotFoundException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}
	}

	static void process(Object[] annoList) {
		final String TARGET_TABLE = "target.Table";
		final String TARGET_COLUMN = "target.Column";
		final String TARGET_AUTHOR = "target.Author";

		for (int i = 0; i < annoList.length; i++) {
			Annotation annotation = getAnnotation(annoList[i]);
			if (annotation.getTypeName().equals(TARGET_TABLE)) {
				showAnnotation(annotation);
			} else if (annotation.getTypeName().equals(TARGET_COLUMN)) {
				showAnnotation(annotation);
			} else if (annotation.getTypeName().equals(TARGET_AUTHOR)) {
				showAnnotation(annotation);
			}
		}
	}

	static Annotation getAnnotation(Object obj) {
		// Get the underlying type of a proxy object in java
		AnnotationImpl annotationImpl = //
				(AnnotationImpl) Proxy.getInvocationHandler(obj);
		return annotationImpl.getAnnotation();
	}

	static void showAnnotation(Annotation annotation) {
		Iterator<?> iterator = annotation.getMemberNames().iterator();
		String rename = "";
		while (iterator.hasNext()) {
			Object keyObj = (Object) iterator.next();
			MemberValue value = annotation.getMemberValue(keyObj.toString());
			rename += keyObj + ": " + value.toString().replaceAll("^\"|\"$", "") + ", ";
			
			/*
			 * if (iterator.hasNext()) { rename += keyObj + ": " +
			 * value.toString().replaceAll("^\"|\"$", "") + ", "; } else { rename += keyObj
			 * + ": " + value; }
			 */

		}
		rename = rename.substring(0, rename.length()-2);
		System.out.println(rename);

	}
}
