package newfield;

import java.io.File;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.bytecode.annotation.Annotation;
import javassist.bytecode.annotation.AnnotationImpl;
import javassist.bytecode.annotation.MemberValue;
import util.UtilMenu;

public class AnnotatedFieldExample4 {
	static String workDir = System.getProperty("user.dir");
	static String inputDir = workDir + File.separator + "classfiles";
	static String outputDir = workDir + File.separator + "output";
	static ClassPool pool;
	static String class_name, first_annotation, second_annotation;
	
	public static void main(String[] args) {
		while (true) {
			UtilMenu.showMenuOptions();
			int option = UtilMenu.getOption();
			switch (option) {
			case 1:
				System.out.println("Enter the four inputs: (e.g, ComponentApp,Column,Author, or ServiceApp,Row,Author)");
				String[] arguments = UtilMenu.getArguments();
				try {
					if (arguments.length == 3) {
						class_name = "target." + arguments[0];
						first_annotation = "target." + arguments[1];
						second_annotation = "target." + arguments[2];

						ClassPool pool = ClassPool.getDefault();
						pool.insertClassPath(inputDir);

						CtClass ct = pool.get(class_name);
						CtField[] all_fields = ct.getFields();
						for (CtField cf : all_fields) {
							process(cf.getAnnotations(), first_annotation, second_annotation);
							//System.out.println("Finished process");
						}
					} else {
						System.out.println("[WRN] Invalid input size");
					}
				} catch (NotFoundException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		}

	}

	static void process(Object[] annoList, String firstannotation, String secondannotation) {
		Annotation annotation2 = null;
		
		for (Object annotationO : annoList) {
			Annotation annotation = getAnnotation(annotationO);
			//System.out.print("Annotated!!");
			if (annotation.getTypeName().equals(firstannotation)) {
			//System.out.println(annotation.getTypeName());	
				for (Object annotationOB : annoList) {
					Annotation annotmp = getAnnotation(annotationOB);
					if (annotmp.getTypeName().equals(secondannotation)) {
						annotation2 = annotmp;
					}
				}
			}
			
		}
		if (annotation2 != null) {
			showAnnotation(annotation2);
			
		}
	}

	static Annotation getAnnotation(Object obj) {
		// Get the underlying type of a proxy object in java
		AnnotationImpl annotationImpl = //
				(AnnotationImpl) Proxy.getInvocationHandler(obj);
		return annotationImpl.getAnnotation();
	}

	static void showAnnotation(Annotation annotation) {
		Iterator<?> iterator = annotation.getMemberNames().iterator();
		String output = "";
		while (iterator.hasNext()) {
			Object keyObj = (Object) iterator.next();
			MemberValue value = annotation.getMemberValue(keyObj.toString());
			output += keyObj + ": " + value.toString().replaceAll("^\"|\"$", "") + ", ";
		}
		System.out.println(output.substring(0, output.length() - 2));
	}
}
