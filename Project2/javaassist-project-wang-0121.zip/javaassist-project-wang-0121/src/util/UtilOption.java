package util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.junit.jupiter.api.Test;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;

public class UtilOption {

	static String workDir = System.getProperty("user.dir");
	static String outputDir = workDir + File.separator + "output";
	public static String Father;
	public static String Child1;
	public static String Child2;
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("=============================================");
		System.out.println("Example Program");

		while (true) {
			System.out.println("=============================================");
			System.out.print("Enter three classes (\"q\" to terminate)\n");
			String[] inputs = getInputs();
			for (int i = 0; i < inputs.length; i++) {
				System.out.println("[DBG] " + i + ": " + inputs[i]);
			}
			if (inputs.length != 3) {
				System.out.println("[WRN] Invalid Input");
			} else {
				String father = inputs[0];
				// print out the input name
				for (int i = 0; i < inputs.length; i++) {
					if ((inputs[i].startsWith("Common") && !father.startsWith("Common"))
							|| (inputs[i].startsWith("Common") && father.startsWith("Common")
									&& inputs[i].length() > father.length())) {
						father = inputs[i];
					}
				}
				String[] child = { "", "" };
				int i = 0;
				for (String name : inputs) {
					if (!name.equals(father)) {
						child[i] = name;
						i++;
					}
				}
				
				Father = father;
				Child1 = child[0];
				Child2 = child[1];
				System.out.println(Father);
				System.out.println(Child1);
				System.out.println(Child2);

				try {
					ClassPool pool = ClassPool.getDefault();
					insertClassPath(pool);
					CtClass ccFather = pool.makeClass(UtilOption.Father);
					ccFather.writeFile(outputDir); // debugWriteFile
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass ccChild1 = pool.makeClass(UtilOption.Child1);
					ccChild1.writeFile(outputDir);
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass ccChild2 = pool.makeClass(UtilOption.Child2);
					ccChild2.writeFile(outputDir);

					ccChild1.defrost(); // modifications of the class definition will be permitted.
					ccChild1.setSuperclass(ccFather);

					ccChild1.writeFile(outputDir);
					System.out.println("[DBG] write output to: " + outputDir);

					ccChild2.defrost(); // modifications of the class definition will be permitted.
					ccChild2.setSuperclass(ccFather);

					ccChild2.writeFile(outputDir);
					System.out.println("[DBG] write output to: " + outputDir);

				} catch (NotFoundException | CannotCompileException | IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	static void insertClassPath(ClassPool pool) throws NotFoundException {
		String strClassPath = outputDir;
		pool.insertClassPath(strClassPath);
		System.out.println("[DBG] insert classpath: " + strClassPath);
	}

	public static String[] getInputs() {
		String input = scanner.nextLine();
		if (input.trim().equalsIgnoreCase("q")) {
			System.err.println("Terminated.");
			System.exit(0);
		}
		List<String> list = new ArrayList<String>();
		String[] inputArr = input.split(",");
		for (String iElem : inputArr) {
			list.add(iElem.trim());
		}
		return list.toArray(new String[0]);
	}
}
