package ex04a.toclass;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtMethod;
import javassist.NotFoundException;
import util.UtilMenu;

public class ToClass {
	private static final String PKG_NAME = "target" + ".";
	private static final String METHOD_NAME = "say";

	public static void main(String[] args) {
		while (true) {
			UtilMenu.showMenuOptions();
			switch (UtilMenu.getOption()) {
			case 1:
				System.out.println("Enter one input (e.g., CommonServiceA or CommonComponentB)");
				String[] inputs = UtilMenu.getArguments();
				String field1 = "id";
				String field2 = "year";
				if (inputs.length == 1) {
					process(inputs[0], field1, field2);
				} else {
					System.out.println("[WRN] Invalid Input\n");
				}
				break;
			default:
				break;
			}
		}
	}

	static void process(String clazz, String field1, String field2) {
		try {
			ClassPool cp = ClassPool.getDefault();
			CtClass cc = cp.get(PKG_NAME + clazz);

			CtConstructor declaredConstructor = cc.getDeclaredConstructor(new CtClass[0]);

			String block1 = "{ " + "System.out.println(\"" + field1 + ": \" + " + field1 + "); }";
			declaredConstructor.insertAfter(block1);

			String block2 = "{ " + "System.out.println(\"" + field2 + ": \" + " + field2 + "); }";

			declaredConstructor.insertAfter(block2);
			Class<?> c = cc.toClass();
			// a place that print the field
			c.newInstance(); // object instantiation
		} catch (NotFoundException | CannotCompileException | //
				InstantiationException | IllegalAccessException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}
}
