package ex01.setsuper;

import java.io.File;
import java.io.IOException;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import target.Rectangle;

public class SetSuperclass {
	static final String SEP = File.separator;
	static String workDir = System.getProperty("user.dir");
	static String outputDir = workDir + SEP + "output";

	public static void main(String[] args) {
		try {
			// System.out.println(args.length);
			if (args.length == 3) {
				String father = args[0];
				// print out the input name
				for (int i = 0; i < args.length; i++) {
					if ((args[i].startsWith("Common") && !father.startsWith("Common")) || (args[i].startsWith("Common")
							&& father.startsWith("Common") && args[i].length() > father.length())) {
						father = args[i];
					}
				}
				String[] child = {"", ""};
				int i = 0;
				for (String name : args) {
					if (!name.equals(father)){
						child[i] = name;
						i++;
					}
				}
				ClassPool pool = ClassPool.getDefault();

				boolean useRuntimeClass = false;
				if (useRuntimeClass) {
					insertClassPathRunTimeClass(pool);
				} else {
					insertClassPath(pool);
				}
				String childClass1 = "target." + child[0];
				String childClass2 = "target." + child[1];
				//System.out.println(childClass1);
				//System.out.println(childClass2);
				
				CtClass cc1 = pool.get(childClass1);
				CtClass cc2 = pool.get(childClass2);
				
				String superClass = "target." + father;
				
				setSuperclass(cc1, superClass, pool);
				setSuperclass(cc2, superClass, pool);
				cc1.writeFile(outputDir);
				cc2.writeFile(outputDir);
				System.out.println("[DBG] write output to: " + outputDir);
			}
			else {
				System.out.println("[DBG] Done");
			}

		} catch (NotFoundException | CannotCompileException |

				IOException e) {
			e.printStackTrace();
		}
	}

	static void insertClassPathRunTimeClass(ClassPool pool) throws NotFoundException {
		ClassClassPath classPath = new ClassClassPath(new Rectangle().getClass());
		pool.insertClassPath(classPath);
		System.out.println("[DBG] insert classpath: " + classPath.toString());
	}

	static void insertClassPath(ClassPool pool) throws NotFoundException {
		String strClassPath = workDir + SEP + "bin"; // eclipse compile dir
		// String strClassPath = workDir + SEP + "classfiles"; // separate dir
		pool.insertClassPath(strClassPath);
		System.out.println("[DBG] insert classpath: " + strClassPath);
	}

	static void setSuperclass(CtClass curClass, String superClass, ClassPool pool)
			throws NotFoundException, CannotCompileException {
		curClass.setSuperclass(pool.get(superClass));
		System.out.println("[DBG] set superclass: " + curClass.getSuperclass().getName() + //
				", subclass: " + curClass.getName());
	}
}
