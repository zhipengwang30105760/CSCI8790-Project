package target;

public class Rectangle {
   public int getVal() {
      return 1;
   }
}
